package com.example.gamepadmapper

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShizukuShell {

    fun isReady(): Boolean = try {
        Shizuku.pingBinder() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    /**
     * Ejecuta un comando de shell con privilegios de shell/ADB a través de Shizuku.
     * Es bloqueante: llamar siempre desde un hilo secundario.
     *
     * Shizuku.newProcess es una API interna en algunas versiones, por eso se usa
     * reflexión. Si cambia en una versión futura, este es el punto a revisar.
     */
    fun exec(command: String): Boolean {
        if (!isReady()) return false
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            process.waitFor() == 0
        } catch (e: Throwable) {
            false
        }
    }

    fun keyEvent(keyCode: Int): Boolean = exec("input keyevent $keyCode")
}
