package com.example.gamepadmapper

import android.content.Context
import android.view.KeyEvent

enum class Direction { UP, DOWN, LEFT, RIGHT }

enum class Action(val label: String, val needsShizuku: Boolean = false) {
    NONE("Ninguna (pasa a la app)"),
    MOUSE_CLICK("Ratón: clic izquierdo"),
    MOVE_UP("Ratón: subir"),
    MOVE_DOWN("Ratón: bajar"),
    MOVE_LEFT("Ratón: izquierda"),
    MOVE_RIGHT("Ratón: derecha"),
    BACK("Atrás"),
    HOME("Inicio"),
    RECENTS("Recientes"),
    NOTIFICATIONS("Notificaciones"),
    SHIZUKU_ENTER("Enter (vía Shizuku)", needsShizuku = true),
    SHIZUKU_ESCAPE("Escape (vía Shizuku)", needsShizuku = true)
}

/** Botones que se pueden remapear, con su keycode de Android. */
val BUTTONS: List<Pair<String, Int>> = listOf(
    "A" to KeyEvent.KEYCODE_BUTTON_A,
    "B" to KeyEvent.KEYCODE_BUTTON_B,
    "X" to KeyEvent.KEYCODE_BUTTON_X,
    "Y" to KeyEvent.KEYCODE_BUTTON_Y,
    "L1" to KeyEvent.KEYCODE_BUTTON_L1,
    "R1" to KeyEvent.KEYCODE_BUTTON_R1,
    "L2" to KeyEvent.KEYCODE_BUTTON_L2,
    "R2" to KeyEvent.KEYCODE_BUTTON_R2,
    "Select" to KeyEvent.KEYCODE_BUTTON_SELECT,
    "Start" to KeyEvent.KEYCODE_BUTTON_START,
    "Modo / Home" to KeyEvent.KEYCODE_BUTTON_MODE,
    "Stick izquierdo (pulsar)" to KeyEvent.KEYCODE_BUTTON_THUMBL,
    "Stick derecho (pulsar)" to KeyEvent.KEYCODE_BUTTON_THUMBR,
    "Cruceta arriba" to KeyEvent.KEYCODE_DPAD_UP,
    "Cruceta abajo" to KeyEvent.KEYCODE_DPAD_DOWN,
    "Cruceta izquierda" to KeyEvent.KEYCODE_DPAD_LEFT,
    "Cruceta derecha" to KeyEvent.KEYCODE_DPAD_RIGHT
)

private val DEFAULTS: Map<Int, Action> = mapOf(
    KeyEvent.KEYCODE_BUTTON_A to Action.MOUSE_CLICK,
    KeyEvent.KEYCODE_BUTTON_B to Action.BACK,
    KeyEvent.KEYCODE_BUTTON_MODE to Action.HOME,
    KeyEvent.KEYCODE_DPAD_UP to Action.MOVE_UP,
    KeyEvent.KEYCODE_DPAD_DOWN to Action.MOVE_DOWN,
    KeyEvent.KEYCODE_DPAD_LEFT to Action.MOVE_LEFT,
    KeyEvent.KEYCODE_DPAD_RIGHT to Action.MOVE_RIGHT
)

class MappingStore(context: Context) {
    private val prefs = context.getSharedPreferences("mappings", Context.MODE_PRIVATE)

    fun actionFor(keyCode: Int): Action {
        val saved = prefs.getString("k$keyCode", null)
        return saved?.let { runCatching { Action.valueOf(it) }.getOrNull() }
            ?: DEFAULTS[keyCode]
            ?: Action.NONE
    }

    fun setAction(keyCode: Int, action: Action) {
        prefs.edit().putString("k$keyCode", action.name).apply()
    }

    /** Combinación que activa/desactiva el ratón virtual (mínimo 2 botones). */
    fun comboKeys(): Set<Int> =
        prefs.getStringSet("combo", null)?.map { it.toInt() }?.toSet()
            ?: setOf(KeyEvent.KEYCODE_BUTTON_SELECT, KeyEvent.KEYCODE_BUTTON_START)

    fun setCombo(keys: Set<Int>) {
        prefs.edit().putStringSet("combo", keys.map { it.toString() }.toSet()).apply()
    }
}
