package com.example.gamepadmapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.InputDevice
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Intercepta las pulsaciones de mandos desde cualquier app.
 *
 * Limitaciones de este enfoque:
 *  - Los botones con acción distinta de NONE se consumen y no llegan a la app de debajo.
 *  - Los ejes analógicos de los sticks no llegan al servicio de accesibilidad;
 *    para eso haría falta leer /dev/input vía Shizuku (ver README).
 */
class GamepadMapperService : AccessibilityService() {

    private val pressed = HashSet<Int>()
    private val store by lazy { MappingStore(this) }
    private lateinit var mouse: VirtualMouse

    override fun onServiceConnected() {
        super.onServiceConnected()
        mouse = VirtualMouse(this) { x, y -> tap(x, y) }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!event.isFromSource(InputDevice.SOURCE_GAMEPAD) &&
            !event.isFromSource(InputDevice.SOURCE_DPAD)
        ) return false

        val down = when (event.action) {
            KeyEvent.ACTION_DOWN -> true
            KeyEvent.ACTION_UP -> false
            else -> return false
        }
        val code = event.keyCode
        val firstPress = down && event.repeatCount == 0

        if (firstPress) pressed.add(code) else if (!down) pressed.remove(code)

        // Combinación que alterna el ratón virtual
        val combo = store.comboKeys()
        if (combo.contains(code)) {
            if (firstPress && combo.size >= 2 && pressed.containsAll(combo)) {
                mouse.toggle()
            }
            return true
        }

        return perform(store.actionFor(code), down)
    }

    /** Devuelve true si el evento queda consumido, false si debe seguir a la app. */
    private fun perform(action: Action, down: Boolean): Boolean = when (action) {
        Action.NONE -> false
        Action.MOUSE_CLICK -> if (mouse.active) {
            if (down) mouse.click()
            true
        } else false
        Action.MOVE_UP -> move(Direction.UP, down)
        Action.MOVE_DOWN -> move(Direction.DOWN, down)
        Action.MOVE_LEFT -> move(Direction.LEFT, down)
        Action.MOVE_RIGHT -> move(Direction.RIGHT, down)
        Action.BACK -> system(GLOBAL_ACTION_BACK, down)
        Action.HOME -> system(GLOBAL_ACTION_HOME, down)
        Action.RECENTS -> system(GLOBAL_ACTION_RECENTS, down)
        Action.NOTIFICATIONS -> system(GLOBAL_ACTION_NOTIFICATIONS, down)
        Action.SHIZUKU_ENTER -> shell(KeyEvent.KEYCODE_ENTER, down)
        Action.SHIZUKU_ESCAPE -> shell(KeyEvent.KEYCODE_ESCAPE, down)
    }

    private fun move(direction: Direction, down: Boolean): Boolean {
        if (!mouse.active) return false // sin ratón activo, la cruceta sigue a la app
        mouse.setDirection(direction, down)
        return true
    }

    private fun system(globalAction: Int, down: Boolean): Boolean {
        if (down) performGlobalAction(globalAction)
        return true
    }

    private fun shell(keyCode: Int, down: Boolean): Boolean {
        if (down) Thread { ShizukuShell.keyEvent(keyCode) }.start()
        return true
    }

    /** Toque en pantalla en la posición del cursor; el overlay no toca, así que llega a la app. */
    private fun tap(x: Float, y: Float) {
        val path = Path().apply {
            moveTo(x, y)
            lineTo(x + 1f, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 50L)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        if (::mouse.isInitialized) mouse.hide()
    }

    override fun onDestroy() {
        if (::mouse.isInitialized) mouse.hide()
        super.onDestroy()
    }
}
