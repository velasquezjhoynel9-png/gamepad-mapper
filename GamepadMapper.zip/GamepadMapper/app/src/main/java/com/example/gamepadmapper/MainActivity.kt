package com.example.gamepadmapper

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.InputDevice
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private val store by lazy { MappingStore(this) }
    private lateinit var status: TextView

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        status = TextView(this).apply { textSize = 15f }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
            addView(status)
            addView(button("1. Activar servicio de accesibilidad") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
            addView(button("2. Pedir permiso de Shizuku (opcional)") {
                if (Shizuku.pingBinder()) Shizuku.requestPermission(1)
            })
            addView(button("Asignar acciones a botones") { showRemapDialog() })
            addView(button("Cambiar combinación del ratón") { showComboDialog() })
        }
        setContentView(root)

        Shizuku.addRequestPermissionResultListener(permissionListener)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }

    private fun refresh() {
        val pads = InputDevice.getDeviceIds()
            .mapNotNull { InputDevice.getDevice(it) }
            .filter { (it.sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD }

        val padText = pads.joinToString("\n") { "• ${it.name}" }
            .ifEmpty { "Ninguno. Empareja un mando por Bluetooth." }

        val shizukuText = when {
            !Shizuku.pingBinder() -> "no está activo"
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> "activo y con permiso"
            else -> "sin permiso"
        }

        val combo = store.comboKeys().mapNotNull { k -> BUTTONS.firstOrNull { it.second == k }?.first }
            .joinToString(" + ")

        status.text = "Mandos detectados:\n$padText\n\n" +
            "Shizuku: $shizukuText\n" +
            "Combinación del ratón: $combo"
    }

    private fun showRemapDialog() {
        val names = BUTTONS.map { it.first }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("¿Qué botón quieres asignar?")
            .setItems(names) { _, i ->
                val (name, code) = BUTTONS[i]
                val actions = Action.values()
                AlertDialog.Builder(this)
                    .setTitle("Acción para $name")
                    .setItems(actions.map { it.label }.toTypedArray()) { _, j ->
                        store.setAction(code, actions[j])
                        refresh()
                    }
                    .show()
            }
            .show()
    }

    private fun showComboDialog() {
        val names = BUTTONS.map { it.first }.toTypedArray()
        val current = store.comboKeys()
        val checked = BUTTONS.map { it.second in current }.toBooleanArray()

        AlertDialog.Builder(this)
            .setTitle("Combinación del ratón (mínimo 2)")
            .setMultiChoiceItems(names, checked) { _, i, isChecked -> checked[i] = isChecked }
            .setPositiveButton("Guardar") { _, _ ->
                val keys = BUTTONS.filterIndexed { i, _ -> checked[i] }.map { it.second }.toSet()
                if (keys.size >= 2) {
                    store.setCombo(keys)
                    refresh()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { onClick() }
    }
}
