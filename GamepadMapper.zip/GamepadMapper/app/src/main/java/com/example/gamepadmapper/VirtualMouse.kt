package com.example.gamepadmapper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/**
 * Cursor virtual dibujado como overlay del servicio de accesibilidad.
 * No requiere el permiso "mostrar sobre otras apps" porque usa TYPE_ACCESSIBILITY_OVERLAY.
 * FLAG_NOT_TOUCHABLE hace que los toques lleguen a la app de debajo.
 */
class VirtualMouse(
    private val context: Context,
    private val onClick: (x: Float, y: Float) -> Unit
) {
    private val dm = context.resources.displayMetrics
    private val wm = context.getSystemService(WindowManager::class.java)
    private val handler = Handler(Looper.getMainLooper())
    private val dirs = HashSet<Direction>()

    private val size = (32 * dm.density).toInt()
    private val speed = (10 * dm.density).toInt()

    private val view = CursorView(context)
    private val params = WindowManager.LayoutParams(
        size,
        size,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = dm.widthPixels / 2
        y = dm.heightPixels / 2
    }

    var active = false
        private set

    private val loop = object : Runnable {
        override fun run() {
            var dx = 0
            var dy = 0
            if (Direction.LEFT in dirs) dx -= speed
            if (Direction.RIGHT in dirs) dx += speed
            if (Direction.UP in dirs) dy -= speed
            if (Direction.DOWN in dirs) dy += speed

            if (dx != 0 || dy != 0) {
                params.x = (params.x + dx).coerceIn(0, dm.widthPixels - size)
                params.y = (params.y + dy).coerceIn(0, dm.heightPixels - size)
                wm.updateViewLayout(view, params)
            }
            handler.postDelayed(this, 16L)
        }
    }

    fun toggle() = if (active) hide() else show()

    fun show() {
        if (active) return
        wm.addView(view, params)
        active = true
        handler.post(loop)
    }

    fun hide() {
        if (!active) return
        handler.removeCallbacks(loop)
        dirs.clear()
        try {
            wm.removeView(view)
        } catch (e: IllegalArgumentException) {
            // La vista ya no estaba adjunta; no hacemos nada.
        }
        active = false
    }

    fun setDirection(direction: Direction, down: Boolean) {
        if (down) dirs.add(direction) else dirs.remove(direction)
    }

    fun click() {
        onClick(params.x + size / 2f, params.y + size / 2f)
    }

    private class CursorView(context: Context) : View(context) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(150, 20, 20, 20)
            style = Paint.Style.FILL
        }
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }

        override fun onDraw(canvas: Canvas) {
            val cx = width / 2f
            val cy = height / 2f
            val r = width / 2f - 4f
            canvas.drawCircle(cx, cy, r, fill)
            canvas.drawCircle(cx, cy, r, stroke)
            canvas.drawCircle(cx, cy, 3f, stroke)
        }
    }
}
