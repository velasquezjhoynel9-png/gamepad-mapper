# Mapeo de mandos (base)

## Compilar
Abrir la carpeta en Android Studio (Ladybug o superior), sincronizar Gradle y generar el APK.
Requisito: minSdk 29 (Android 10).

## Uso
1. Emparejar el mando por Bluetooth en los ajustes del sistema.
2. Abrir la app y activar el servicio de accesibilidad.
3. (Opcional) Instalar Shizuku, iniciarlo (Depuración inalámbrica o ADB) y conceder el permiso desde la app.
4. "Asignar acciones a botones" para remapear cada botón.
5. "Cambiar combinación del ratón" (por defecto Select + Start) para mostrar u ocultar el cursor.
6. Con el ratón activo, la cruceta mueve el cursor y el botón asignado a "clic izquierdo" hace clic donde está.

## Pendiente / siguientes pasos
- Sticks analógicos: leer el dispositivo con `getevent` vía Shizuku y mover el cursor con el stick.
- Re-inyectar botones no mapeados a las apps (actualmente se pasan solo si la acción es "Ninguna").
- Clic derecho y arrastre.
- Revisar la reflexión sobre `Shizuku.newProcess` según la versión de Shizuku instalada.
- No probado en dispositivo real: validar mapeo de keycodes con tu mando concreto.
